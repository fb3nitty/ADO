
<#
.SYNOPSIS
    Extracts repository-level permissions and branch policies from Azure DevOps Services
.DESCRIPTION
    This script connects to Azure DevOps Services and extracts repository permissions,
    branch policies, and security settings for audit and documentation purposes.
.PARAMETER OrganizationUrl
    The URL of your Azure DevOps organization (e.g., https://dev.azure.com/yourorg)
.PARAMETER ProjectName
    Name of the specific project to analyze
.PARAMETER RepositoryName
    Name of specific repository (optional - if not provided, analyzes all repositories in project)
.PARAMETER PersonalAccessToken
    Personal Access Token with appropriate permissions to read repository settings
.PARAMETER OutputPath
    Path where the output CSV file will be saved
.EXAMPLE
    .\Get-AzureDevOpsRepoPermissions.ps1 -OrganizationUrl "https://dev.azure.com/myorg" -ProjectName "MyProject" -PersonalAccessToken $pat
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$OrganizationUrl,
    
    [Parameter(Mandatory=$true)]
    [string]$ProjectName,
    
    [Parameter(Mandatory=$false)]
    [string]$RepositoryName,
    
    [Parameter(Mandatory=$true)]
    [string]$PersonalAccessToken,
    
    [Parameter(Mandatory=$false)]
    [string]$OutputPath = ".\repo_permissions_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
)

# Function to create authentication header
function Get-AuthHeader {
    param([string]$Token)
    $base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$Token"))
    return @{Authorization = "Basic $base64AuthInfo"}
}

# Function to make REST API calls with error handling
function Invoke-AzureDevOpsApi {
    param(
        [string]$Uri,
        [hashtable]$Headers,
        [string]$Method = "GET"
    )
    
    try {
        $response = Invoke-RestMethod -Uri $Uri -Headers $Headers -Method $Method -ContentType "application/json"
        return $response
    }
    catch {
        Write-Warning "API call failed for $Uri : $($_.Exception.Message)"
        return $null
    }
}

# Function to analyze repository permissions and policies
function Get-RepositoryPermissions {
    param(
        [string]$OrgUrl,
        [string]$Project,
        [string]$Repository,
        [hashtable]$Headers
    )
    
    $repoResults = @()
    
    Write-Host "    Analyzing repository: $Repository" -ForegroundColor Cyan
    
    # Get repository details
    $repoUri = "$OrgUrl/$Project/_apis/git/repositories/$Repository?api-version=7.1-preview.1"
    $repoInfo = Invoke-AzureDevOpsApi -Uri $repoUri -Headers $Headers
    
    if (-not $repoInfo) {
        Write-Warning "Could not retrieve repository information for $Repository"
        return $repoResults
    }
    
    # Get repository permissions (Git namespace)
    $gitNamespaceId = "2e9eb7ed-3c0a-47d4-87c1-0ffdd275fd87"
    $aclUri = "$OrgUrl/_apis/accesscontrollists/$gitNamespaceId?api-version=7.1-preview.1"
    $acls = Invoke-AzureDevOpsApi -Uri $aclUri -Headers $Headers
    
    if ($acls -and $acls.value) {
        foreach ($acl in $acls.value) {
            if ($acl.token -like "*$($repoInfo.id)*") {
                if ($acl.acesDictionary) {
                    foreach ($ace in $acl.acesDictionary.PSObject.Properties) {
                        $repoResults += [PSCustomObject]@{
                            ProjectName = $Project
                            RepositoryName = $Repository
                            RepositoryId = $repoInfo.id
                            SecurityToken = $acl.token
                            IdentityDescriptor = $ace.Name
                            Allow = $ace.Value.allow
                            Deny = $ace.Value.deny
                            PermissionType = "Repository"
                            InheritPermissions = $acl.inheritPermissions
                            LastModified = $repoInfo.lastModifiedDate
                            DefaultBranch = $repoInfo.defaultBranch
                            Size = $repoInfo.size
                        }
                    }
                }
            }
        }
    }
    
    # Get branch policies
    $policiesUri = "$OrgUrl/$Project/_apis/policy/configurations?repositoryId=$($repoInfo.id)&api-version=7.1-preview.1"
    $policies = Invoke-AzureDevOpsApi -Uri $policiesUri -Headers $Headers
    
    if ($policies -and $policies.value) {
        foreach ($policy in $policies.value) {
            $branchName = "All Branches"
            if ($policy.settings.scope -and $policy.settings.scope[0].refName) {
                $branchName = $policy.settings.scope[0].refName -replace "refs/heads/", ""
            }
            
            $repoResults += [PSCustomObject]@{
                ProjectName = $Project
                RepositoryName = $Repository
                RepositoryId = $repoInfo.id
                PolicyType = $policy.type.displayName
                PolicyId = $policy.id
                BranchName = $branchName
                IsEnabled = $policy.isEnabled
                IsBlocking = $policy.isBlocking
                PermissionType = "BranchPolicy"
                Settings = ($policy.settings | ConvertTo-Json -Compress -Depth 3)
                CreatedDate = $policy.createdDate
                ModifiedDate = $policy.revision.revisionDate
            }
        }
    }
    
    # Get branch security (for protected branches)
    $branchesUri = "$OrgUrl/$Project/_apis/git/repositories/$Repository/refs?filter=heads&api-version=7.1-preview.1"
    $branches = Invoke-AzureDevOpsApi -Uri $branchesUri -Headers $Headers
    
    if ($branches -and $branches.value) {
        foreach ($branch in $branches.value | Select-Object -First 10) { # Limit to first 10 branches to avoid too much data
            $branchName = $branch.name -replace "refs/heads/", ""
            $branchToken = "repoV2/$($repoInfo.id)/refs/heads/$branchName"
            
            # Check if this branch has specific permissions
            $branchAcl = $acls.value | Where-Object { $_.token -eq $branchToken }
            if ($branchAcl) {
                $repoResults += [PSCustomObject]@{
                    ProjectName = $Project
                    RepositoryName = $Repository
                    RepositoryId = $repoInfo.id
                    BranchName = $branchName
                    BranchObjectId = $branch.objectId
                    PermissionType = "BranchSecurity"
                    HasSpecificPermissions = $true
                    InheritPermissions = $branchAcl.inheritPermissions
                    AceCount = if ($branchAcl.acesDictionary) { $branchAcl.acesDictionary.Count } else { 0 }
                }
            }
        }
    }
    
    return $repoResults
}

# Main execution
try {
    Write-Host "Starting Azure DevOps Repository Permissions Extraction..." -ForegroundColor Green
    
    # Validate organization URL format
    if ($OrganizationUrl -notmatch "^https://dev\.azure\.com/[^/]+/?$") {
        throw "Invalid organization URL format. Expected: https://dev.azure.com/yourorg"
    }
    
    $headers = Get-AuthHeader -Token $PersonalAccessToken
    $allResults = @()
    
    Write-Host "Analyzing project: $ProjectName" -ForegroundColor Yellow
    
    # Get list of repositories to analyze
    if ($RepositoryName) {
        $repositoriesToAnalyze = @($RepositoryName)
    } else {
        Write-Host "  Getting list of all repositories..." -ForegroundColor Yellow
        $reposUri = "$OrganizationUrl/$ProjectName/_apis/git/repositories?api-version=7.1-preview.1"
        $repositories = Invoke-AzureDevOpsApi -Uri $reposUri -Headers $headers
        
        if ($repositories -and $repositories.value) {
            $repositoriesToAnalyze = $repositories.value | ForEach-Object { $_.name }
        } else {
            throw "No repositories found or unable to retrieve repositories list for project $ProjectName"
        }
    }
    
    Write-Host "  Found $($repositoriesToAnalyze.Count) repository(ies) to analyze" -ForegroundColor Green
    
    # Analyze each repository
    foreach ($repository in $repositoriesToAnalyze) {
        try {
            $repoResults = Get-RepositoryPermissions -OrgUrl $OrganizationUrl -Project $ProjectName -Repository $repository -Headers $headers
            $allResults += $repoResults
        }
        catch {
            Write-Warning "Failed to analyze repository '$repository': $($_.Exception.Message)"
        }
    }
    
    # Export results to CSV
    Write-Host "Exporting results to: $OutputPath" -ForegroundColor Green
    $allResults | Export-Csv -Path $OutputPath -NoTypeInformation -Encoding UTF8
    
    Write-Host "Repository permissions extraction completed successfully!" -ForegroundColor Green
    Write-Host "Total items extracted: $($allResults.Count)" -ForegroundColor Cyan
    Write-Host "Repositories analyzed: $($repositoriesToAnalyze.Count)" -ForegroundColor Cyan
    Write-Host "Output saved to: $OutputPath" -ForegroundColor Cyan
}
catch {
    Write-Error "Script execution failed: $($_.Exception.Message)"
    Write-Error "Stack trace: $($_.ScriptStackTrace)"
    exit 1
}
